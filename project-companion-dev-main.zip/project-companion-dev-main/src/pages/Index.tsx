import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Search, Building, MessageSquare, ChevronLeft, ChevronRight, Bed, Bath, Users, Star, Shield, Clock } from "lucide-react";
import { useRef, useState, useEffect } from "react";

const featuredListings = [
  { id: 1, title: "Spacious Studio Near Campus", price: "$1,200", unit: "month", type: "STUDIO", beds: 1, baths: 1, max: 2, rating: 4.8, image: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=400&h=260&fit=crop" },
  { id: 2, title: "Cozy 3-Bed Shared House", price: "$850", unit: "person", type: "SHARED", beds: 3, baths: 2, max: 3, rating: 4.5, image: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=400&h=260&fit=crop" },
  { id: 3, title: "Modern Dorm Room", price: "$700", unit: "month", type: "STUDIO", beds: 1, baths: 0.5, max: 1, rating: 4.2, image: "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400&h=260&fit=crop" },
  { id: 4, title: "Luxury Apartment Downtown", price: "$1,500", unit: "month", type: "STUDIO", beds: 2, baths: 1, max: 2, rating: 4.9, image: "https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=400&h=260&fit=crop" },
  { id: 5, title: "Budget-Friendly Shared Room", price: "$450", unit: "person", type: "SHARED", beds: 2, baths: 1, max: 4, rating: 4.0, image: "https://images.unsplash.com/photo-1536376072261-38c75010e6c9?w=400&h=260&fit=crop" },
  { id: 6, title: "Penthouse Student Suite", price: "$2,000", unit: "month", type: "STUDIO", beds: 2, baths: 2, max: 2, rating: 5.0, image: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&h=260&fit=crop" },
];

const neighborhoods = [
  { name: "Campus Central", count: "24 listings", image: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=300&h=300&fit=crop" },
  { name: "Riverside Greens", count: "18 listings", image: "https://images.unsplash.com/photo-1416169607655-0c2b3ce2e1cc?w=300&h=300&fit=crop" },
  { name: "Artisan District", count: "31 listings", image: "https://images.unsplash.com/photo-1519999482648-25049ddd37b1?w=300&h=300&fit=crop" },
  { name: "Tech Hub Lofts", count: "15 listings", image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=300&h=300&fit=crop" },
];

const testimonials = [
  { quote: "DormLink made finding my off-campus apartment so easy and stress-free. The filters were incredibly helpful, and I found a perfect place within days!", name: "Sarah K.", role: "University Student", rating: 5 },
  { quote: "As a landlord, DormLink connects me with quality student tenants quickly. The platform is intuitive, and managing my properties has never been simpler.", name: "Mark T.", role: "Property Owner", rating: 5 },
  { quote: "Moving to a new city for university was daunting, but DormLink helped me secure a great place right next to campus. Excellent support and listings!", name: "Jessica L.", role: "Exchange Student", rating: 4 },
];

const stats = [
  { value: "10K+", label: "Active Students" },
  { value: "2,500+", label: "Verified Listings" },
  { value: "98%", label: "Satisfaction Rate" },
  { value: "50+", label: "Universities Covered" },
];

// Simple intersection observer hook
function useInView(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); obs.disconnect(); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

const Index = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const heroSection = useInView();
  const featuredSection = useInView();
  const howSection = useInView();
  const neighborhoodSection = useInView();
  const statsSection = useInView();
  const testimonialSection = useInView();

  const handleScroll = () => {
    if (!scrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
    setCanScrollLeft(scrollLeft > 0);
    setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
  };

  const scroll = (dir: "left" | "right") => {
    scrollRef.current?.scrollBy({ left: dir === "left" ? -340 : 340, behavior: "smooth" });
  };

  return (
    <div className="overflow-hidden">
      {/* Hero */}
      <section ref={heroSection.ref} className="container py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className={`${heroSection.inView ? "animate-fade-in-left" : "opacity-0"}`}>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold leading-tight tracking-tight">
              {t("hero.title1")}<br />
              <span className="text-gradient">{t("hero.title2")}</span><br />
              {t("hero.title3")}
            </h1>
            <p className="mt-6 text-muted-foreground text-lg max-w-md leading-relaxed">
              {t("hero.description")}
            </p>
            <Button
              size="lg"
              className="mt-8 rounded-full px-8 gap-2 animate-pulse-glow hover-lift"
              onClick={() => navigate("/listings")}
            >
              {t("hero.cta")} <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
          <div className={`hidden lg:block ${heroSection.inView ? "animate-fade-in-right" : "opacity-0"}`}>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=600&h=420&fit=crop"
                alt="Student housing"
                className="rounded-2xl object-cover w-full shadow-2xl hover-lift"
              />
              {/* Floating badge */}
              <div className="absolute -bottom-4 -left-4 glass rounded-xl px-4 py-3 animate-float shadow-lg">
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-xs font-bold">Verified Listings</p>
                    <p className="text-[10px] text-muted-foreground">100% Trusted</p>
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 glass rounded-xl px-4 py-3 animate-float stagger-3 shadow-lg">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-xs font-bold">Quick Booking</p>
                    <p className="text-[10px] text-muted-foreground">Under 24hrs</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section ref={statsSection.ref} className="border-y bg-primary/5">
        <div className="container py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, i) => (
              <div
                key={stat.label}
                className={`text-center ${statsSection.inView ? "animate-scale-in" : "opacity-0"} stagger-${i + 1}`}
              >
                <p className="text-3xl font-extrabold text-primary">{stat.value}</p>
                <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Listings */}
      <section ref={featuredSection.ref} className="py-16 bg-secondary/30">
        <div className="container">
          <div className={`flex items-center justify-between mb-8 ${featuredSection.inView ? "animate-fade-in" : "opacity-0"}`}>
            <div>
              <h2 className="text-2xl sm:text-3xl font-bold">{t("featured.title")}</h2>
              <p className="text-muted-foreground text-sm mt-1">Hand-picked properties for students</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="icon" className="rounded-full h-9 w-9 hover-lift" disabled={!canScrollLeft} onClick={() => scroll("left")}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" className="rounded-full h-9 w-9 hover-lift" disabled={!canScrollRight} onClick={() => scroll("right")}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div ref={scrollRef} onScroll={handleScroll} className="flex gap-5 overflow-x-auto pb-4 snap-x snap-mandatory" style={{ scrollbarWidth: "none" }}>
            {featuredListings.map((listing, i) => (
              <div
                key={listing.id}
                className={`min-w-[300px] snap-start rounded-xl border bg-card overflow-hidden hover-lift hover-glow cursor-pointer group ${featuredSection.inView ? "animate-slide-up" : "opacity-0"} stagger-${i + 1}`}
              >
                <div className="relative overflow-hidden">
                  <img src={listing.image} alt={listing.title} className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110" />
                  <span className={`absolute top-3 left-3 text-xs font-bold px-2.5 py-1 rounded-md text-primary-foreground ${listing.type === "SHARED" ? "bg-accent-foreground/70" : "bg-primary"}`}>
                    {listing.type}
                  </span>
                  <div className="absolute top-3 right-3 glass rounded-md px-2 py-0.5 flex items-center gap-1">
                    <Star className="h-3 w-3 text-yellow-500 fill-yellow-500" />
                    <span className="text-xs font-bold">{listing.rating}</span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-sm group-hover:text-primary transition-colors">{listing.title}</h3>
                  <p className="text-primary font-bold mt-1">{listing.price}<span className="text-muted-foreground font-normal text-xs">/{t(`featured.${listing.unit}`)}</span></p>
                  <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><Bed className="h-3.5 w-3.5" />{listing.beds} {t("featured.bed")}</span>
                    <span className="flex items-center gap-1"><Bath className="h-3.5 w-3.5" />{listing.baths} {t("featured.bath")}</span>
                    <span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" />{listing.max} {t("featured.max")}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section ref={howSection.ref} className="container py-20 text-center">
        <h2 className={`text-2xl sm:text-3xl font-bold mb-4 ${howSection.inView ? "animate-fade-in" : "opacity-0"}`}>{t("howItWorks.title")}</h2>
        <p className={`text-muted-foreground mb-12 max-w-lg mx-auto ${howSection.inView ? "animate-fade-in stagger-1" : "opacity-0"}`}>
          Getting started is simple — find, review, and secure your perfect student home in just a few steps.
        </p>
        <div className="grid sm:grid-cols-3 gap-8 max-w-3xl mx-auto">
          {[
            { icon: Search, title: t("howItWorks.search"), desc: t("howItWorks.searchDesc"), path: "/listings", step: "01" },
            { icon: Building, title: t("howItWorks.view"), desc: t("howItWorks.viewDesc"), path: undefined, step: "02" },
            { icon: MessageSquare, title: t("howItWorks.secure"), desc: t("howItWorks.secureDesc"), path: undefined, step: "03" },
          ].map((step, i) => (
            <div
              key={i}
              onClick={step.path ? () => navigate(step.path!) : undefined}
              className={`relative flex flex-col items-center p-6 rounded-2xl border bg-card hover-lift hover-glow cursor-pointer group ${
                howSection.inView ? "animate-scale-in" : "opacity-0"
              } stagger-${i + 1} ${step.path ? "ring-1 ring-primary/20" : ""}`}
            >
              <span className="absolute -top-3 -right-3 h-8 w-8 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center">
                {step.step}
              </span>
              <div className="h-14 w-14 rounded-xl bg-secondary group-hover:bg-primary/10 flex items-center justify-center mb-4 transition-colors duration-300">
                <step.icon className="h-6 w-6 text-primary transition-transform duration-300 group-hover:scale-110" />
              </div>
              <h3 className="font-semibold mb-2">{step.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Neighborhoods */}
      <section ref={neighborhoodSection.ref} className="py-16 bg-secondary/30">
        <div className="container text-center">
          <h2 className={`text-2xl sm:text-3xl font-bold mb-2 ${neighborhoodSection.inView ? "animate-fade-in" : "opacity-0"}`}>{t("neighborhoods.title")}</h2>
          <div className={`w-10 h-1 bg-primary rounded mx-auto mb-10 ${neighborhoodSection.inView ? "animate-scale-in" : "opacity-0"}`} />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {neighborhoods.map((n, i) => (
              <div
                key={n.name}
                className={`relative rounded-xl overflow-hidden aspect-square cursor-pointer group hover-lift ${
                  neighborhoodSection.inView ? "animate-scale-in" : "opacity-0"
                } stagger-${i + 1}`}
              >
                <img src={n.image} alt={n.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent transition-opacity group-hover:from-black/90" />
                <div className="absolute bottom-4 left-4 text-left">
                  <span className="text-white font-semibold text-sm">{n.name}</span>
                  <p className="text-white/70 text-xs mt-0.5">{n.count}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section ref={testimonialSection.ref} className="container py-20 text-center">
        <h2 className={`text-2xl sm:text-3xl font-bold mb-4 ${testimonialSection.inView ? "animate-fade-in" : "opacity-0"}`}>{t("testimonials.title")}</h2>
        <p className={`text-muted-foreground mb-12 ${testimonialSection.inView ? "animate-fade-in stagger-1" : "opacity-0"}`}>
          See what students and landlords are saying about DormLink
        </p>
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((item, i) => (
            <div
              key={i}
              className={`border rounded-xl p-6 text-left bg-card hover-lift hover-glow group ${
                testimonialSection.inView ? "animate-slide-up" : "opacity-0"
              } stagger-${i + 1}`}
            >
              <div className="flex gap-0.5 mb-3">
                {Array.from({ length: item.rating }).map((_, s) => (
                  <Star key={s} className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                ))}
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">"{item.quote}"</p>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center font-bold text-sm text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
                  {item.name.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold text-sm">{item.name}</p>
                  <p className="text-xs text-muted-foreground">{item.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary/5">
        <div className="container text-center">
          <h2 className="text-2xl sm:text-3xl font-bold mb-4">Ready to Find Your Perfect Home?</h2>
          <p className="text-muted-foreground max-w-md mx-auto mb-8">
            Join thousands of students who found their ideal housing through DormLink.
          </p>
          <div className="flex items-center justify-center gap-4">
            <Button size="lg" className="rounded-full px-8 gap-2 hover-lift" onClick={() => navigate("/listings")}>
              Browse Listings <ArrowRight className="h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" className="rounded-full px-8 hover-lift" onClick={() => navigate("/create-account")}>
              Sign Up Free
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
